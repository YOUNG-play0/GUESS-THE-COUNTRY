import { useState, useCallback, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Screen, GameMode, Difficulty } from './types';
import { useStorage } from './hooks/useStorage';
import { useGameEngine } from './hooks/useGameEngine';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';
import WorldBackground from './components/WorldBackground';
import HomeScreen from './components/HomeScreen';
import NameEntry from './components/NameEntry';
import ModeSelect from './components/ModeSelect';
import GameScreen from './components/GameScreen';
import GameOver from './components/GameOver';
import StatsScreen from './components/StatsScreen';
import ProfileScreen from './components/ProfileScreen';
import ChatAssistant from './components/ChatAssistant';
import LanguageSelector from './components/LanguageSelector';

function AppContent() {
  const { isRTL } = useLanguage();
  const [screen, setScreen] = useState<Screen>('home');
  const [lastMode, setLastMode] = useState<GameMode>('classic');
  const [lastDifficulty, setLastDifficulty] = useState<Difficulty>('easy');
  const gameRecordedRef = useRef(false);
  const {
    stats,
    addXP,
    recordGame,
    setPlayerName,
  } = useStorage();

  const {
    gameState,
    currentQuestion,
    selectedAnswer,
    isCorrect,
    showResult,
    chronoTimeLeft,
    startGame,
    handleAnswer,
    nextQuestion,
    endGame,
    clearTimers,
  } = useGameEngine();

  useEffect(() => {
    if (gameState && !gameState.isActive && screen === 'game' && !gameRecordedRef.current) {
      gameRecordedRef.current = true;
      addXP(gameState.xpEarned);
      recordGame(
        gameState.score,
        gameState.mode,
        gameState.bestCombo,
        gameState.correctAnswers,
        gameState.questionsAnswered
      );
      setScreen('game-over');
    }
  }, [gameState?.isActive]);

  const handleStartGame = useCallback((mode: GameMode, difficulty: Difficulty) => {
    setLastMode(mode);
    setLastDifficulty(difficulty);
    gameRecordedRef.current = false;
    startGame(mode, difficulty);
    setScreen('game');
  }, [startGame]);

  const handleQuitGame = useCallback(() => {
    clearTimers();
    if (gameState) endGame();
  }, [clearTimers, endGame, gameState]);

  const handlePlayAgain = useCallback(() => {
    handleStartGame(lastMode, lastDifficulty);
  }, [handleStartGame, lastMode, lastDifficulty]);

  const handleNameSubmit = useCallback((name: string) => {
    setPlayerName(name);
    setScreen('mode-select');
  }, [setPlayerName]);

  const handleNext = useCallback(() => {
    if (gameState && !gameState.isActive) {
      setScreen('game-over');
      return;
    }
    nextQuestion();
  }, [gameState, nextQuestion]);

  const isNewBest = gameState ? gameState.score >= stats.bestScore && gameState.score > 0 : false;

  return (
    <div
      className="min-h-screen font-sans text-white overflow-x-hidden no-select relative"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <WorldBackground />

      {/* Language Selector */}
      <div className="fixed top-3 right-3 z-50">
        <LanguageSelector />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        <AnimatePresence mode="wait">
          {screen === 'home' && (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <HomeScreen stats={stats} onNavigate={setScreen} />
            </motion.div>
          )}
          {screen === 'name-entry' && (
            <motion.div key="name-entry" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <NameEntry onSubmit={handleNameSubmit} onBack={() => setScreen('home')} />
            </motion.div>
          )}
          {screen === 'mode-select' && (
            <motion.div key="mode-select" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <ModeSelect stats={stats} onStart={handleStartGame} onBack={() => setScreen('home')} />
            </motion.div>
          )}
          {screen === 'game' && gameState && (
            <motion.div key="game" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
              <GameScreen
                gameState={gameState}
                currentQuestion={currentQuestion}
                selectedAnswer={selectedAnswer}
                isCorrect={isCorrect}
                showResult={showResult}
                chronoTimeLeft={chronoTimeLeft}
                onAnswer={handleAnswer}
                onNext={handleNext}
                onQuit={handleQuitGame}
              />
            </motion.div>
          )}
          {screen === 'game-over' && gameState && (
            <motion.div key="game-over" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <GameOver
                gameState={gameState}
                playerLevel={stats.level}
                playerXP={stats.xp}
                isNewBest={isNewBest}
                onPlayAgain={handlePlayAgain}
                onHome={() => setScreen('home')}
              />
            </motion.div>
          )}
          {screen === 'stats' && (
            <motion.div key="stats" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <StatsScreen stats={stats} onBack={() => setScreen('home')} />
            </motion.div>
          )}
          {screen === 'profile' && (
            <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
              <ProfileScreen stats={stats} onBack={() => setScreen('home')} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Chat Assistant - always visible */}
      <ChatAssistant />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
