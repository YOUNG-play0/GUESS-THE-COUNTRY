import { motion } from 'framer-motion';
import { Globe2, BarChart3, User, Play, Zap } from 'lucide-react';
import { PlayerStats, Screen, XP_LEVELS } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface Props {
  stats: PlayerStats;
  onNavigate: (screen: Screen) => void;
}

export default function HomeScreen({ stats, onNavigate }: Props) {
  const { t } = useLanguage();
  const currentLevel = XP_LEVELS.find(l => l.level === stats.level) || XP_LEVELS[0];
  const nextLevel = XP_LEVELS.find(l => l.level === stats.level + 1);
  const xpProgress = nextLevel
    ? ((stats.xp - currentLevel.xp) / (nextLevel.xp - currentLevel.xp)) * 100
    : 100;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-5 py-16">
      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="text-center mb-6"
      >
        <div className="flex items-center justify-center gap-3 mb-3">
          <Globe2 className="w-12 h-12 text-indigo-400 spin-slow" />
        </div>
        <h1 className="text-4xl sm:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 tracking-tight leading-tight">
          {t.home_title}
        </h1>
        <h1 className="text-5xl sm:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 tracking-tight -mt-1 leading-tight">
          COUNTRY
        </h1>
        <p className="text-slate-400 mt-2 text-xs sm:text-sm font-medium tracking-wider uppercase">
          {t.home_subtitle}
        </p>
      </motion.div>

      {/* Player Level Badge */}
      {stats.name && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-6 w-full max-w-sm bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl px-5 py-3 flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
            {stats.level}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white font-semibold text-sm truncate">{stats.name}</p>
            <p className="text-indigo-300 text-xs">{currentLevel.title}</p>
            <div className="w-full h-1.5 bg-white/10 rounded-full mt-1 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${xpProgress}%` }}
                transition={{ duration: 1, delay: 0.5 }}
              />
            </div>
          </div>
          <div className="text-right shrink-0">
            <p className="text-yellow-400 font-bold text-xs flex items-center gap-1">
              <Zap className="w-3 h-3" /> {stats.xp} XP
            </p>
          </div>
        </motion.div>
      )}

      {/* Main Menu */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="w-full max-w-sm space-y-3"
      >
        <motion.button
          whileTap={{ scale: 0.96 }}
          onClick={() => stats.name ? onNavigate('mode-select') : onNavigate('name-entry')}
          className="w-full py-4 px-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 active:from-indigo-700 active:to-purple-700 text-white font-bold text-lg rounded-2xl shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-3 transition-all"
        >
          <Play className="w-6 h-6" fill="currentColor" />
          {t.play_now}
        </motion.button>

        <div className="grid grid-cols-2 gap-3">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('stats')}
            className="py-4 px-3 bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 active:bg-white/15 text-white rounded-2xl flex flex-col items-center gap-2 transition-all"
          >
            <BarChart3 className="w-6 h-6 text-emerald-400" />
            <span className="text-xs font-semibold">{t.stats}</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('profile')}
            className="py-4 px-3 bg-white/5 backdrop-blur-xl border border-white/10 hover:bg-white/10 active:bg-white/15 text-white rounded-2xl flex flex-col items-center gap-2 transition-all"
          >
            <User className="w-6 h-6 text-blue-400" />
            <span className="text-xs font-semibold">{t.profile}</span>
          </motion.button>
        </div>
      </motion.div>

      {/* Quick Stats */}
      {stats.totalGames > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 flex gap-6 text-center"
        >
          <div>
            <p className="text-2xl font-bold text-white">{stats.totalGames}</p>
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{t.games_short}</p>
          </div>
          <div className="w-px bg-white/10" />
          <div>
            <p className="text-2xl font-bold text-yellow-400">{stats.bestScore}</p>
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{t.best_short}</p>
          </div>
          <div className="w-px bg-white/10" />
          <div>
            <p className="text-2xl font-bold text-emerald-400">
              {stats.totalAnswers > 0 ? Math.round((stats.correctAnswers / stats.totalAnswers) * 100) : 0}%
            </p>
            <p className="text-[10px] text-slate-400 uppercase tracking-wider">{t.accuracy_short}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
